from distutils.core import setup
setup(
	name = 'athletelist',
	version = '1.0.0',
	py_modules = ['athletelist'],
	author = 'zhoush721',
	author_email='zhoushuhua721@qq.com',
	license='MIT',
	url='',
	description='A simple printer of nested lists'
)